import time
import json
import torch
import argparse
from transformers import AutoTokenizer, AutoModelForCausalLM

parser = argparse.ArgumentParser(description='Prefiller')
parser.add_argument('--model', help='Model Path', required=True)
args = parser.parse_args()

tokenizer = AutoTokenizer.from_pretrained(args.model)
model = AutoModelForCausalLM.from_pretrained(
    args.model,
    use_cache=False,
    device_map='auto',
    dtype=torch.bfloat16,
)

print('ready', flush=True)
text = json.loads(input())
for t in text:
    input_dict = tokenizer(t, return_tensors="pt")
    input_dict = {k: v.cuda() for k, v in input_dict.items()}
    with torch.no_grad():
        loss = model(**input_dict, labels=input_dict["input_ids"]).loss
    print(loss.item(), flush=True)
